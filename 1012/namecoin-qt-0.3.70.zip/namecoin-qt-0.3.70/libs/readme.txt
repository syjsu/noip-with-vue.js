Put libraries here, namely:

 boost
 OpenSSL
 Berkeley DB
 MiniUPnPc


Alternatively, provide paths to these libraries when running qmake. An example for Windows is shown in project\run_qmake.bat, which uses the following directories:

 boost_1_50_0
 openssl-1.0.1e
 db-4.7.25.NC
 miniupnpc-1.8.20130211

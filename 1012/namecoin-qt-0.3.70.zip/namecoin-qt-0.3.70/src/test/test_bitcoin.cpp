#define BOOST_TEST_MODULE uint160
#include <boost/test/unit_test.hpp>

#include "uint160_tests.cpp"
#include "uint256_tests.cpp"


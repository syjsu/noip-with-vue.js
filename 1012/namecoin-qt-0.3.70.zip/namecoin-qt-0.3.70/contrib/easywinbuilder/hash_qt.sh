echo Hash of Qt binary [experimental]...
bash dahash.sh $ROOTPATHSH/release/${COINNAME}-qt.exe
echo phelix got: 924b34d99151e2b58f2be1a74e18c76915b5ef12e5479f58b3a6117b8280129f (v3.70)
echo
echo

